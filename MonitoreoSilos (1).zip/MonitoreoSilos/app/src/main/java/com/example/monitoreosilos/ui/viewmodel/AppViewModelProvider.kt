package com.example.monitoreosilos.ui.viewmodel

import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.monitoreosilos.SilosApp

/** Fábrica única: crea cada ViewModel con sus repositorios (reemplaza la fábrica manual de la Guía 14). */
object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer { AuthViewModel(app().container.authRepository) }
        initializer { SilosViewModel(app().container.siloRepository) }
        initializer { DetalleSiloViewModel(createSavedStateHandle(), app().container.siloRepository) }
        initializer { RegistrarMovimientoViewModel(createSavedStateHandle(), app().container.siloRepository) }
    }
}

private fun CreationExtras.app(): SilosApp =
    this[AndroidViewModelFactory.APPLICATION_KEY] as SilosApp
