package com.example.monitoreosilos.domain.model

import java.util.Locale
import kotlin.math.roundToInt

/** Semaforización (RF-03): Normal >30%, Advertencia 15–30%, Crítico <15%. */
enum class EstadoSilo(val etiqueta: String) {
    NORMAL("Normal"),
    ADVERTENCIA("Advertencia"),
    CRITICO("Crítico");

    companion object {
        const val UMBRAL_CRITICO = 15.0
        const val UMBRAL_NORMAL = 30.0

        fun desdePorcentaje(p: Double): EstadoSilo = when {
            p < UMBRAL_CRITICO -> CRITICO
            p <= UMBRAL_NORMAL -> ADVERTENCIA
            else -> NORMAL
        }
    }
}

enum class TipoMovimiento(val etiqueta: String, val titulo: String) {
    CARGA("Carga", "Carga de silo"),
    DESCARGA("Descarga", "Descarga de silo"),
    CONSUMO("Consumo", "Consumo de alimento"),
    MANTENIMIENTO("Mantenimiento", "Mantenimiento de silo")
}

enum class Rol(val etiqueta: String) {
    OPERARIO("Operario"),
    SUPERVISOR("Supervisor"),
    JEFATURA("Jefatura")
}

data class Sesion(val usuario: String, val rol: Rol)

data class Usuario(
    val id: String,
    val nombre: String,          // Ej: "Juan Pérez"
    val email: String,           // Ej: "juan.perez@empresa.cl"
    val rol: Rol,                // OPERARIO, SUPERVISOR, JEFATURA
    val granjaAsignada: String? = null, // Ej: "Granja 01 - Melipilla"
    val rut: String? = null      // Ej: "12.345.678-9"
)
data class Silo(
    val id: String,
    val granjaId: Int,
    val granjaNombre: String,
    val tipo: String,
    val capacidadT: Double,
    val nivelT: Double,
    val enReposicion: Boolean
) {
    /** "SIL-01" -> "Silo 01" */
    val nombre: String get() = "Silo " + id.substringAfter('-', id)

    val porcentajeExacto: Double
        get() = if (capacidadT <= 0) 0.0 else (nivelT / capacidadT * 100).coerceIn(0.0, 100.0)

    val porcentaje: Int get() = porcentajeExacto.roundToInt()
    val progreso: Float get() = (porcentajeExacto / 100).toFloat()
    val estado: EstadoSilo get() = EstadoSilo.desdePorcentaje(porcentajeExacto)
}

data class Granja(
    val id: Int,
    val nombre: String,
    val estado: String, // "Activo" | "Mantenimiento"
    val silos: List<Silo>
)

data class Movimiento(
    val id: Long,
    val siloId: String,
    val tipo: TipoMovimiento,
    val cantidadT: Double,
    val fechaHora: Long,
    val detalle: String,
    val pendienteSync: Boolean
)

/** 1200.0 -> "1,200 t" (formato de las capturas). */
fun Double.enToneladas(): String =
    if (this % 1.0 == 0.0) String.format(Locale.US, "%,d t", this.toLong())
    else String.format(Locale.US, "%,.2f t", this)
