package com.example.monitoreosilos.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.monitoreosilos.domain.model.Usuario
import com.example.monitoreosilos.ui.components.BotonSecundario
import com.example.monitoreosilos.ui.components.InsigniaSolida
import com.example.monitoreosilos.ui.components.TarjetaBorde
import com.example.monitoreosilos.ui.theme.AzulPrimario
import com.example.monitoreosilos.ui.theme.GrisTexto

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerfilUsuarioScreen(
    usuario: Usuario?,
    onVolver: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mi Perfil") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver"
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (usuario == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Avatar circular con iniciales
                Surface(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape),
                    color = AzulPrimario
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = usuario.nombre.take(2).uppercase(),
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = usuario.nombre,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                InsigniaSolida(
                    texto = usuario.rol.etiqueta,
                    color = AzulPrimario
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Tarjeta con detalle de información personal
                TarjetaBorde {
                    Text(
                        text = "Información de la Cuenta",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    FilaDatoPerfil(
                        icono = Icons.Default.Person,
                        etiqueta = "Nombre Completo",
                        valor = usuario.nombre
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    usuario.rut?.let {
                        FilaDatoPerfil(
                            icono = Icons.Default.Badge,
                            etiqueta = "RUT",
                            valor = it
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    }

                    FilaDatoPerfil(
                        icono = Icons.Default.Email,
                        etiqueta = "Correo Electrónico",
                        valor = usuario.email
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    FilaDatoPerfil(
                        icono = Icons.Default.Work,
                        etiqueta = "Cargo / Rol Asignado",
                        valor = usuario.rol.etiqueta
                    )

                    usuario.granjaAsignada?.let {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        FilaDatoPerfil(
                            icono = Icons.Default.LocationOn,
                            etiqueta = "Granja Asignada",
                            valor = it
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                BotonSecundario(
                    texto = "Volver",
                    onClick = onVolver
                )
            }
        }
    }
}

@Composable
private fun FilaDatoPerfil(
    icono: ImageVector,
    etiqueta: String,
    valor: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icono,
            contentDescription = null,
            tint = AzulPrimario,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = etiqueta,
                fontSize = 11.sp,
                color = GrisTexto
            )
            Text(
                text = valor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}