package com.example.monitoreosilos.data

import android.content.Context
import com.example.monitoreosilos.data.local.SilosDatabase
import com.example.monitoreosilos.data.prefs.SesionRepository
import com.example.monitoreosilos.data.repository.AuthRepository
import com.example.monitoreosilos.data.repository.SiloRepository

/** Contenedor de dependencias simple (sin Hilt) para mantener la guía fácil de seguir. */
class AppContainer(context: Context) {
    private val db = SilosDatabase.obtener(context)
    private val sesionRepository = SesionRepository(context)

    val siloRepository = SiloRepository(db)
    val authRepository = AuthRepository(db.usuarioDao(), sesionRepository)

    suspend fun sembrarDatosIniciales() {
        siloRepository.sembrarSiVacio()
        authRepository.sembrarUsuariosDemo()
    }
}
