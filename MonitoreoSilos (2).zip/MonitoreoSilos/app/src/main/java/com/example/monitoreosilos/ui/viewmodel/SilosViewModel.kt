package com.example.monitoreosilos.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.monitoreosilos.data.repository.SiloRepository
import com.example.monitoreosilos.domain.model.Granja
import com.example.monitoreosilos.domain.model.Silo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

/** Estado compartido por "Silos por granja" y "Selección silo y estado". */
class SilosViewModel(repo: SiloRepository) : ViewModel() {

    val granjas: StateFlow<List<Granja>> = repo.granjas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val pendientes: StateFlow<Int> = repo.pendientesSync()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    private val _criticoPrimero = MutableStateFlow(false)
    val criticoPrimero = _criticoPrimero.asStateFlow()

    val silos: StateFlow<List<Silo>> = combine(repo.silos(), _criticoPrimero) { lista, critico ->
        if (critico) lista.sortedBy { it.porcentajeExacto } else lista
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun alternarCriticoPrimero() = _criticoPrimero.update { !it }
}
