package com.example.monitoreosilos.ui.navigation

object AppRoutes {
    const val LOGIN = "login"
    const val REGISTRO = "registro"
    const val HOME = "silos_por_granja"
    const val ESTADO = "estado_silos"
    const val DETALLE = "detalle/{siloId}"
    const val MOVIMIENTO = "movimiento/{siloId}"

    fun detalle(siloId: String) = "detalle/$siloId"
    fun movimiento(siloId: String) = "movimiento/$siloId"
}
