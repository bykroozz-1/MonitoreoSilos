package com.example.monitoreosilos.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.monitoreosilos.data.repository.AuthRepository
import com.example.monitoreosilos.domain.model.Rol
import com.example.monitoreosilos.domain.model.Sesion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val usuario: String = "",
    val clave: String = "",
    val errorUsuario: String? = null,
    val errorClave: String? = null,
    val errorGeneral: String? = null,
    val cargando: Boolean = false
)


class AuthViewModel(private val repo: AuthRepository) : ViewModel() {

    val sesion: StateFlow<Sesion?> =
        repo.sesion.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _login = MutableStateFlow(LoginUiState())
    val login = _login.asStateFlow()


    suspend fun haySesion(): Boolean = repo.sesion.first() != null

    // ---- Login ----
    fun onUsuarioLogin(v: String) = _login.update { it.copy(usuario = v, errorUsuario = null, errorGeneral = null) }
    fun onClaveLogin(v: String) = _login.update { it.copy(clave = v, errorClave = null, errorGeneral = null) }

    fun iniciarSesion(onExito: () -> Unit) {
        val s = _login.value
        val eu = if (s.usuario.isBlank()) "Ingresa tu nombre de usuario" else null
        val ec = if (s.clave.isBlank()) "Ingresa tu contraseña" else null
        if (eu != null || ec != null) {
            _login.update { it.copy(errorUsuario = eu, errorClave = ec) }
            return
        }
        viewModelScope.launch {
            _login.update { it.copy(cargando = true) }
            repo.iniciarSesion(s.usuario, s.clave)
                .onSuccess {
                    _login.value = LoginUiState()
                    onExito()
                }
                .onFailure { e -> _login.update { it.copy(cargando = false, errorGeneral = e.message) } }
        }
    }


    fun cerrarSesion() {
        viewModelScope.launch { repo.cerrarSesion() }
    }
}
