package com.example.monitoreosilos.data.repository

import com.example.monitoreosilos.data.local.UsuarioDao
import com.example.monitoreosilos.data.local.UsuarioEntity
import com.example.monitoreosilos.data.prefs.SesionRepository
import com.example.monitoreosilos.domain.model.Rol
import com.example.monitoreosilos.domain.model.Sesion
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest

/** RF-01: autenticación local por rol (funciona sin conexión). */
class AuthRepository(
    private val dao: UsuarioDao,
    private val sesionRepo: SesionRepository
) {
    val sesion: Flow<Sesion?> = sesionRepo.sesion

    suspend fun registrar(usuario: String, clave: String, rol: Rol): Result<Unit> {
        val nombre = usuario.trim().lowercase()
        if (dao.buscar(nombre) != null) {
            return Result.failure(IllegalArgumentException("Ese nombre de usuario ya existe"))
        }
        dao.insertar(UsuarioEntity(nombre, hash(clave), rol.name))
        sesionRepo.guardar(nombre, rol)
        return Result.success(Unit)
    }

    suspend fun iniciarSesion(usuario: String, clave: String): Result<Rol> {
        val nombre = usuario.trim().lowercase()
        val encontrado = dao.buscar(nombre)
        if (encontrado == null || encontrado.claveHash != hash(clave)) {
            return Result.failure(IllegalArgumentException("Usuario o contraseña incorrectos"))
        }
        val rol = Rol.valueOf(encontrado.rol)
        sesionRepo.guardar(nombre, rol)
        return Result.success(rol)
    }

    suspend fun cerrarSesion() = sesionRepo.limpiar()

    /** Usuarios de prueba: operario / supervisor / jefatura, clave 1234. */
    suspend fun sembrarUsuariosDemo() {
        Rol.entries.forEach { rol ->
            dao.insertar(UsuarioEntity(rol.name.lowercase(), hash("1234"), rol.name))
        }
    }

    private fun hash(clave: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(clave.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
