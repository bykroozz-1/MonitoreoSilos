package com.example.monitoreosilos.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [GranjaEntity::class, SiloEntity::class, MovimientoEntity::class, UsuarioEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SilosDatabase : RoomDatabase() {
    abstract fun siloDao(): SiloDao
    abstract fun movimientoDao(): MovimientoDao
    abstract fun usuarioDao(): UsuarioDao

    companion object {
        @Volatile
        private var INSTANCE: SilosDatabase? = null

        fun obtener(context: Context): SilosDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SilosDatabase::class.java,
                    "silos_db"
                ).build().also { INSTANCE = it }
            }
    }
}
