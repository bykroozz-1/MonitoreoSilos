package com.example.monitoreosilos.ui.viewmodel

import android.graphics.Bitmap
import android.net.Uri
import android.util.Patterns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.monitoreosilos.data.prefs.PerfilRepository
import com.example.monitoreosilos.data.repository.AuthRepository
import com.example.monitoreosilos.domain.model.Sesion
import com.example.monitoreosilos.domain.model.Usuario
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PerfilFormUiState(
    val editando: Boolean = false,
    val nombre: String = "",
    val email: String = "",
    val rut: String = "",
    val errorNombre: String? = null,
    val errorEmail: String? = null,
    val errorRut: String? = null
)

class PerfilViewModel(
    private val perfilRepo: PerfilRepository,
    authRepo: AuthRepository
) : ViewModel() {

    @OptIn(ExperimentalCoroutinesApi::class)
    val usuario: StateFlow<Usuario?> = authRepo.sesion
        .flatMapLatest<Sesion?, Usuario?> { s ->
            if (s == null) flowOf(null) else perfilRepo.perfil(s)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _form = MutableStateFlow(PerfilFormUiState())
    val form = _form.asStateFlow()

    // ---- Foto de perfil ----
    fun fotoDesdeCamara(bitmap: Bitmap) {
        val id = usuario.value?.id ?: return
        viewModelScope.launch { perfilRepo.guardarFotoCamara(id, bitmap) }
    }

    fun fotoDesdeGaleria(uri: Uri) {
        val id = usuario.value?.id ?: return
        viewModelScope.launch { perfilRepo.guardarFotoGaleria(id, uri) }
    }

    fun quitarFoto() {
        val id = usuario.value?.id ?: return
        viewModelScope.launch { perfilRepo.quitarFoto(id) }
    }

    // ---- Formulario de edición ----
    fun iniciarEdicion() {
        val u = usuario.value ?: return
        _form.value = PerfilFormUiState(
            editando = true,
            nombre = u.nombre,
            email = u.email,
            rut = u.rut.orEmpty()
        )
    }

    fun cancelarEdicion() {
        _form.value = PerfilFormUiState()
    }

    fun onNombre(v: String) = _form.update { it.copy(nombre = v, errorNombre = null) }
    fun onEmail(v: String) = _form.update { it.copy(email = v, errorEmail = null) }
    fun onRut(v: String) = _form.update { it.copy(rut = v, errorRut = null) }

    fun guardar() {
        val id = usuario.value?.id ?: return
        val f = _form.value
        val nombre = f.nombre.trim()
        val email = f.email.trim()
        val rut = f.rut.trim()

        val errorNombre = if (nombre.length < 2) "Ingresa tu nombre completo" else null
        val errorEmail = if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) "Correo no válido" else null
        val errorRut = if (rut.isNotEmpty() && !rutValido(rut)) "RUT no válido (ej: 12.345.678-5)" else null

        if (errorNombre != null || errorEmail != null || errorRut != null) {
            _form.update {
                it.copy(errorNombre = errorNombre, errorEmail = errorEmail, errorRut = errorRut)
            }
            return
        }
        viewModelScope.launch {
            perfilRepo.guardarDatos(id, nombre, email, if (rut.isEmpty()) "" else formatearRut(rut))
            _form.value = PerfilFormUiState()
        }
    }

    // ---- RUT chileno (módulo 11) ----
    private fun limpiarRut(rut: String) = rut.replace(".", "").replace("-", "").trim().uppercase()

    private fun rutValido(rut: String): Boolean {
        val r = limpiarRut(rut)
        if (r.length !in 7..9) return false
        val cuerpo = r.dropLast(1)
        if (!cuerpo.all { it.isDigit() }) return false
        var suma = 0
        var mult = 2
        for (c in cuerpo.reversed()) {
            suma += c.digitToInt() * mult
            mult = if (mult == 7) 2 else mult + 1
        }
        val dv = when (val resto = 11 - suma % 11) {
            11 -> '0'
            10 -> 'K'
            else -> resto.digitToChar()
        }
        return r.last() == dv
    }

    /** 187654327 -> 18.765.432-7 */
    private fun formatearRut(rut: String): String {
        val r = limpiarRut(rut)
        val cuerpo = r.dropLast(1).reversed().chunked(3).joinToString(".").reversed()
        return "$cuerpo-${r.last()}"
    }
}
