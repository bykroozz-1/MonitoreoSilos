package com.example.monitoreosilos.data.repository

import androidx.room.withTransaction
import com.example.monitoreosilos.data.local.GranjaEntity
import com.example.monitoreosilos.data.local.MovimientoEntity
import com.example.monitoreosilos.data.local.SiloConGranjaRow
import com.example.monitoreosilos.data.local.SiloEntity
import com.example.monitoreosilos.data.local.SilosDatabase
import com.example.monitoreosilos.domain.model.EstadoSilo
import com.example.monitoreosilos.domain.model.Granja
import com.example.monitoreosilos.domain.model.Movimiento
import com.example.monitoreosilos.domain.model.Silo
import com.example.monitoreosilos.domain.model.TipoMovimiento
import com.example.monitoreosilos.domain.model.enToneladas
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlin.math.roundToLong

/**
 * Fuente única de datos (Offline-First): la UI siempre lee desde Room.
 * Los movimientos se guardan con pendienteSync = true hasta que exista
 * una API remota que los reciba (ver README, sección "Siguientes pasos").
 */
class SiloRepository(private val db: SilosDatabase) {
    private val siloDao = db.siloDao()
    private val movDao = db.movimientoDao()

    fun granjas(): Flow<List<Granja>> = siloDao.granjasConSilos().map { lista ->
        lista.map { gs ->
            Granja(
                id = gs.granja.id,
                nombre = gs.granja.nombre,
                estado = gs.granja.estado,
                silos = gs.silos.sortedBy { it.id }.map { it.aDominio(gs.granja.nombre) }
            )
        }
    }

    fun silos(): Flow<List<Silo>> = siloDao.silosConGranja().map { l -> l.map { it.aDominio() } }

    fun silo(id: String): Flow<Silo?> = siloDao.siloConGranja(id).map { it?.aDominio() }

    fun movimientos(siloId: String): Flow<List<Movimiento>> =
        movDao.porSilo(siloId).map { l -> l.map { it.aDominio() } }

    fun pendientesSync(): Flow<Int> = movDao.contarPendientes()

    suspend fun silosCriticos(): List<Silo> =
        siloDao.silosConGranjaUnaVez().map { it.aDominio() }.filter { it.estado == EstadoSilo.CRITICO }

    suspend fun marcarReposicion(siloId: String, valor: Boolean) =
        siloDao.marcarReposicion(siloId, valor)

    /** HU-02 / RF-04: guarda el movimiento y recalcula el nivel en una sola transacción. */
    suspend fun registrarMovimiento(
        siloId: String,
        tipo: TipoMovimiento,
        cantidadT: Double
    ): Result<Unit> = db.withTransaction {
        val silo = siloDao.obtener(siloId)
            ?: return@withTransaction Result.failure<Unit>(IllegalArgumentException("Silo no encontrado"))

        val nuevoNivel = when (tipo) {
            TipoMovimiento.CARGA -> silo.nivelT + cantidadT
            TipoMovimiento.DESCARGA, TipoMovimiento.CONSUMO -> silo.nivelT - cantidadT
            TipoMovimiento.MANTENIMIENTO -> silo.nivelT
        }.redondear()

        if (nuevoNivel < 0) {
            return@withTransaction Result.failure<Unit>(
                IllegalArgumentException("La cantidad supera el nivel actual (${silo.nivelT.enToneladas()}).")
            )
        }
        if (nuevoNivel > silo.capacidadT) {
            return@withTransaction Result.failure<Unit>(
                IllegalArgumentException("La cantidad supera la capacidad del silo (${silo.capacidadT.enToneladas()}).")
            )
        }

        movDao.insertar(
            MovimientoEntity(
                siloId = siloId,
                tipo = tipo.name,
                cantidadT = cantidadT,
                fechaHora = System.currentTimeMillis(),
                detalle = descripcion(tipo, cantidadT, silo.tipo, siloId),
                pendienteSync = true
            )
        )
        siloDao.actualizarNivel(siloId, nuevoNivel)
        Result.success(Unit)
    }

    /** Datos de ejemplo basados en las capturas de diseño. */
    suspend fun sembrarSiVacio() {
        if (siloDao.contarSilos() > 0) return
        siloDao.insertarGranjas(
            listOf(
                GranjaEntity(1, "Granja 01", "Activo"),
                GranjaEntity(2, "Granja 02", "Mantenimiento")
            )
        )
        siloDao.insertarSilos(
            listOf(
                SiloEntity("SIL-01", 1, "Maíz", 1200.0, 216.0),
                SiloEntity("SIL-02", 1, "Soya", 900.0, 531.0),
                SiloEntity("SIL-03", 1, "Trigo", 750.0, 615.0),
                SiloEntity("SIL-04", 2, "Sorgo", 1000.0, 40.0),
                SiloEntity("SIL-05", 2, "Avena", 800.0, 584.0)
            )
        )
        val ahora = System.currentTimeMillis()
        val ayer = ahora - 86_400_000L
        movDao.insertar(MovimientoEntity(siloId = "SIL-01", tipo = TipoMovimiento.CARGA.name, cantidadT = 120.0,
            fechaHora = ayer, detalle = "Ingreso de 120 t de maíz", pendienteSync = false))
        movDao.insertar(MovimientoEntity(siloId = "SIL-01", tipo = TipoMovimiento.DESCARGA.name, cantidadT = 88.0,
            fechaHora = ayer - 600_000L, detalle = "Salida de 88 t de maíz", pendienteSync = false))
        movDao.insertar(MovimientoEntity(siloId = "SIL-01", tipo = TipoMovimiento.MANTENIMIENTO.name, cantidadT = 0.0,
            fechaHora = ayer - 1_200_000L, detalle = "Mantenimiento preventivo silo 1", pendienteSync = false))
    }

    private fun Double.redondear() = (this * 100).roundToLong() / 100.0

    private fun descripcion(tipo: TipoMovimiento, cantidadT: Double, alimento: String, siloId: String): String {
        val c = cantidadT.enToneladas()
        val a = alimento.lowercase()
        return when (tipo) {
            TipoMovimiento.CARGA -> "Ingreso de $c de $a"
            TipoMovimiento.DESCARGA -> "Salida de $c de $a"
            TipoMovimiento.CONSUMO -> "Consumo de $c de $a"
            TipoMovimiento.MANTENIMIENTO -> "Mantenimiento preventivo $siloId"
        }
    }
}

private fun SiloEntity.aDominio(granjaNombre: String) =
    Silo(id, granjaId, granjaNombre, tipo, capacidadT, nivelT, enReposicion)

private fun SiloConGranjaRow.aDominio() =
    Silo(id, granjaId, granjaNombre, tipo, capacidadT, nivelT, enReposicion)

private fun MovimientoEntity.aDominio() =
    Movimiento(id, siloId, TipoMovimiento.valueOf(tipo), cantidadT, fechaHora, detalle, pendienteSync)
