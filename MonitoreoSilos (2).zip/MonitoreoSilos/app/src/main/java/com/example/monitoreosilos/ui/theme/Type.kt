package com.example.monitoreosilos.ui.theme

import androidx.compose.material3.Typography

// Roboto por defecto, igual que en las capturas.
val Typography = Typography()
