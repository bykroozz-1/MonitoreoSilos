package com.example.monitoreosilos.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "granjas")
data class GranjaEntity(
    @PrimaryKey val id: Int,
    val nombre: String,
    val estado: String
)

@Entity(
    tableName = "silos",
    foreignKeys = [ForeignKey(
        entity = GranjaEntity::class,
        parentColumns = ["id"],
        childColumns = ["granjaId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("granjaId")]
)
data class SiloEntity(
    @PrimaryKey val id: String,
    val granjaId: Int,
    val tipo: String,
    val capacidadT: Double,
    val nivelT: Double,
    val enReposicion: Boolean = false
)

@Entity(tableName = "movimientos", indices = [Index("siloId")])
data class MovimientoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val siloId: String,
    val tipo: String,
    val cantidadT: Double,
    val fechaHora: Long,
    val detalle: String,
    /** true = guardado solo en el dispositivo, falta enviarlo al servidor (RF-05). */
    val pendienteSync: Boolean = true
)

@Entity(tableName = "usuarios")
data class UsuarioEntity(
    @PrimaryKey val usuario: String,
    val claveHash: String,
    val rol: String
)

data class GranjaConSilos(
    @Embedded val granja: GranjaEntity,
    @Relation(parentColumn = "id", entityColumn = "granjaId")
    val silos: List<SiloEntity>
)

data class SiloConGranjaRow(
    val id: String,
    val granjaId: Int,
    val granjaNombre: String,
    val tipo: String,
    val capacidadT: Double,
    val nivelT: Double,
    val enReposicion: Boolean
)
