package com.example.monitoreosilos.ui.screen

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.monitoreosilos.domain.model.Movimiento
import com.example.monitoreosilos.domain.model.TipoMovimiento
import com.example.monitoreosilos.domain.model.enToneladas
import com.example.monitoreosilos.ui.components.BarraNivel
import com.example.monitoreosilos.ui.components.BotonPrimario
import com.example.monitoreosilos.ui.components.BotonSecundario
import com.example.monitoreosilos.ui.components.EncabezadoPantalla
import com.example.monitoreosilos.ui.components.EtiquetaEstado
import com.example.monitoreosilos.ui.components.FilaDatosSilo
import com.example.monitoreosilos.ui.components.InsigniaSolida
import com.example.monitoreosilos.ui.components.TarjetaBorde
import com.example.monitoreosilos.ui.theme.AzulPrimario
import com.example.monitoreosilos.ui.theme.GrisBorde
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.theme.VerdeActivo
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import androidx.compose.material.icons.filled.Menu
import com.example.monitoreosilos.ui.viewmodel.DetalleSiloViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun DetalleSiloScreen(
    puedeCoordinar: Boolean,
    onMenu: () -> Unit,
    onRegistrarMovimiento: () -> Unit,
    onVolver: () -> Unit,
    viewModel: DetalleSiloViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val silo by viewModel.silo.collectAsStateWithLifecycle()
    val movimientos by viewModel.movimientos.collectAsStateWithLifecycle()
    var seleccionado by remember { mutableStateOf<Movimiento?>(null) }
    val s = silo

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        // ENCABEZADO CENTRADO
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Flecha de regreso (Izquierda)
            IconButton(onClick = onVolver) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver"
                )
            }

            // 2. Título Centrado (Centro)
            Text(
                text = s?.nombre ?: " ",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )

            // 3. Botón de Menú (Derecha)
            IconButton(onClick = onMenu) {
                Icon(
                    imageVector = Icons.Default.Menu, // Requiere import androidx.compose.material.icons.filled.Menu
                    contentDescription = "Menú"
                )
            }

        }

        Spacer(Modifier.height(12.dp))

        if (s == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                TarjetaBorde {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Estado de hoy",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        InsigniaSolida(
                            texto = if (s.enReposicion) "En reposición" else "Activo",
                            color = if (s.enReposicion) AzulPrimario else VerdeActivo
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.id, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GrisTexto)
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        EtiquetaEstado(s.estado)
                        Spacer(Modifier.weight(1f))
                        Text("${s.porcentaje}% disponible", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    FilaDatosSilo(s.tipo, s.capacidadT.enToneladas(), s.nivelT.enToneladas())
                    Spacer(Modifier.height(8.dp))
                    BarraNivel(s.progreso)
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = GrisBorde)
                    Spacer(Modifier.height(12.dp))

                    Text(
                        "Historial de movimientos",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))

                    if (movimientos.isEmpty()) {
                        Text(
                            "Aún no hay movimientos registrados.",
                            fontSize = 12.sp,
                            color = GrisTexto,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    movimientos.take(30).groupBy { etiquetaDia(it.fechaHora) }.forEach { (dia, lista) ->
                        Text(
                            dia,
                            fontSize = 11.sp,
                            color = GrisTexto,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        )
                        lista.forEach { mov ->
                            FilaMovimiento(mov, onDetalles = { seleccionado = mov })
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (s != null) {
                BotonPrimario("Registrar movimiento", onRegistrarMovimiento)
                if (puedeCoordinar) {
                    BotonSecundario(
                        texto = if (s.enReposicion) "Quitar de reposición" else "Marcar en reposición",
                        onClick = { viewModel.alternarReposicion(s.enReposicion) }
                    )
                }
                // BOTÓN SECUNDARIO "VOLVER"
                BotonSecundario("Volver", onVolver)
            }
        }
    }

    seleccionado?.let { mov ->
        AlertDialog(
            onDismissRequest = { seleccionado = null },
            confirmButton = { TextButton(onClick = { seleccionado = null }) { Text("Cerrar") } },
            title = { Text(mov.tipo.titulo) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(mov.detalle)
                    if (mov.tipo != TipoMovimiento.MANTENIMIENTO) {
                        Text("Cantidad: ${mov.cantidadT.enToneladas()}")
                    }
                    Text("Fecha: ${formatoFechaHora(mov.fechaHora)}")
                    Text(
                        if (mov.pendienteSync) "Estado: pendiente de sincronizar" else "Estado: sincronizado",
                        color = GrisTexto
                    )
                }
            }
        )
    }
}

@Composable
private fun FilaMovimiento(mov: Movimiento, onDetalles: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .border(1.dp, GrisBorde, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(iconoDe(mov.tipo), contentDescription = null, modifier = Modifier.size(28.dp))
        Spacer(Modifier.padding(horizontal = 6.dp))
        Column(Modifier.weight(1f)) {
            Text(mov.tipo.titulo, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(mov.detalle, fontSize = 11.sp, color = GrisTexto)
        }
        Button(
            onClick = onDetalles,
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = AzulPrimario),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
            modifier = Modifier.height(30.dp)
        ) { Text("Detalles", fontSize = 12.sp) }
    }
}

private fun iconoDe(tipo: TipoMovimiento): ImageVector = when (tipo) {
    TipoMovimiento.CARGA -> Icons.Default.KeyboardArrowUp
    TipoMovimiento.DESCARGA -> Icons.Default.KeyboardArrowDown
    TipoMovimiento.CONSUMO -> Icons.Default.Restaurant
    TipoMovimiento.MANTENIMIENTO -> Icons.Default.Build
}

private fun fechaDe(ts: Long): LocalDate =
    Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).toLocalDate()

private fun etiquetaDia(ts: Long): String {
    val fecha = fechaDe(ts)
    val hoy = LocalDate.now()
    return when (fecha) {
        hoy -> "Hoy"
        hoy.minusDays(1) -> "Ayer"
        else -> fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    }
}

private fun formatoFechaHora(ts: Long): String =
    Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))