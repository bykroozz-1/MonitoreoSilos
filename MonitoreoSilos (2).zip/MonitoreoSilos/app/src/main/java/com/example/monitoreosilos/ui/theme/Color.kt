package com.example.monitoreosilos.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.monitoreosilos.domain.model.EstadoSilo

val AzulPrimario = Color(0xFF0A8CFF)
val GrisBorde = Color(0xFFE3E5E8)
val GrisTexto = Color(0xFF5F6368)
val GrisPista = Color(0xFFC9CCD1)
val GrisChip = Color(0xFFF1F2F4)
val RosaCampo = Color(0xFFE6D4D4)

val VerdeActivo = Color(0xFF2EC45B)
val NaranjaMantenimiento = Color(0xFFFF8A1F)

val VerdeNormal = Color(0xFF16A870)
val VerdeNormalFondo = Color(0xFFE6F7EF)
val AmbarAdvertencia = Color(0xFFE59A0B)
val AmbarAdvertenciaFondo = Color(0xFFFFF4DC)
val RojoCritico = Color(0xFFDC3545)
val RojoCriticoFondo = Color(0xFFFDE8EA)

fun EstadoSilo.color(): Color = when (this) {
    EstadoSilo.NORMAL -> VerdeNormal
    EstadoSilo.ADVERTENCIA -> AmbarAdvertencia
    EstadoSilo.CRITICO -> RojoCritico
}

fun EstadoSilo.fondo(): Color = when (this) {
    EstadoSilo.NORMAL -> VerdeNormalFondo
    EstadoSilo.ADVERTENCIA -> AmbarAdvertenciaFondo
    EstadoSilo.CRITICO -> RojoCriticoFondo
}
