package com.example.monitoreosilos.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.monitoreosilos.domain.model.Rol
import com.example.monitoreosilos.domain.model.Sesion
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "sesion")

class SesionRepository(private val context: Context) {
    private companion object {
        val USUARIO = stringPreferencesKey("usuario")
        val ROL = stringPreferencesKey("rol")
    }

    val sesion: Flow<Sesion?> = context.dataStore.data.map { p ->
        val usuario = p[USUARIO]
        val rol = p[ROL]?.let { runCatching { Rol.valueOf(it) }.getOrNull() }
        if (usuario.isNullOrBlank() || rol == null) null else Sesion(usuario, rol)
    }

    suspend fun guardar(usuario: String, rol: Rol) {
        context.dataStore.edit {
            it[USUARIO] = usuario
            it[ROL] = rol.name
        }
    }

    suspend fun limpiar() {
        context.dataStore.edit { it.clear() }
    }
}
