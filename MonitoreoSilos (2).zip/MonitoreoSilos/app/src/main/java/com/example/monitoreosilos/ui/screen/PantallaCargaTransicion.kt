package com.example.monitoreosilos.ui.screen

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.monitoreosilos.ui.theme.AzulPrimario
import com.example.monitoreosilos.ui.theme.GrisBorde
import com.example.monitoreosilos.ui.theme.GrisTexto

@Composable
fun PantallaCargaTransicion(
    onCargaCompletada: () -> Unit
) {
    // Animador de progreso lineal desde 0.0 hasta 1.0
    val progreso = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Anima el llenado del círculo durante exactamente 3000 milisegundos (3 segundos)
        progreso.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = 3000,
                easing = LinearEasing
            )
        )
        // Al finalizar los 3 segundos, redirige a la pantalla principal
        onCargaCompletada()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White), // Fondo completamente blanco
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Rueda con llenado progresivo
            CircularProgressIndicator(
                progress = { progreso.value },
                modifier = Modifier.size(76.dp),
                color = AzulPrimario,
                trackColor = GrisBorde,
                strokeWidth = 6.dp
            )

            Spacer(modifier = Modifier.height(24.dp))
            
        }
    }
}