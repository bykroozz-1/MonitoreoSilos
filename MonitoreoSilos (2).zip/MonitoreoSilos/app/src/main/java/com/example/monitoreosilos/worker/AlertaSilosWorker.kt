package com.example.monitoreosilos.worker

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.monitoreosilos.MainActivity
import com.example.monitoreosilos.SilosApp
import com.example.monitoreosilos.domain.model.enToneladas

class AlertaSilosWorker(
    contexto: Context,
    parametros: WorkerParameters
) : CoroutineWorker(contexto, parametros) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val app = applicationContext as SilosApp
        val criticos = app.container.siloRepository.silosCriticos()
        if (criticos.isEmpty()) return Result.success()

        val sinPermiso = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                applicationContext, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        if (sinPermiso) return Result.success()

        val manager = NotificationManagerCompat.from(applicationContext)
        criticos.forEach { silo ->
            val intent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(MainActivity.EXTRA_SILO_ID, silo.id)
            }
            val pendiente = PendingIntent.getActivity(
                applicationContext,
                silo.id.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notificacion = NotificationCompat.Builder(applicationContext, SilosApp.CANAL_ALERTAS)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("${silo.nombre} en nivel crítico")
                .setContentText("Quedan ${silo.porcentaje}% (${silo.nivelT.enToneladas()}) en ${silo.granjaNombre}.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendiente)
                .build()
            manager.notify(silo.id.hashCode(), notificacion)
        }
        return Result.success()
    }
}
