package com.example.monitoreosilos.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.monitoreosilos.domain.model.Rol
import com.example.monitoreosilos.ui.screen.DetalleSiloScreen
import com.example.monitoreosilos.ui.screen.EstadoSilosScreen
import com.example.monitoreosilos.ui.screen.LoginScreen
import com.example.monitoreosilos.ui.screen.PantallaCargaTransicion
import com.example.monitoreosilos.ui.screen.PerfilUsuarioScreen
import com.example.monitoreosilos.ui.screen.RegistrarMovimientoScreen
import com.example.monitoreosilos.ui.screen.SilosPorGranjaScreen
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import com.example.monitoreosilos.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch

private const val RUTA_CARGA = "pantalla_carga"
private const val RUTA_PERFIL = "perfil"

@Composable
fun AppNavigation(
    siloDesdeNotificacion: String?,
    onNotificacionAtendida: () -> Unit,
    authViewModel: AuthViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    // La ruta inicial se decide una sola vez (sesión guardada en DataStore).
    var rutaInicial by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        rutaInicial = if (authViewModel.haySesion()) AppRoutes.HOME else AppRoutes.LOGIN
    }
    val inicio = rutaInicial
    if (inicio == null) {
        Box(Modifier.fillMaxSize().background(Color.White))
        return
    }

    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val sesion by authViewModel.sesion.collectAsStateWithLifecycle()
    val entrada by navController.currentBackStackEntryAsState()
    val rutaActual = entrada?.destination?.route

    // Deshabilita gestos de menú durante el Login o la Pantalla de Carga
    val enAutenticacionOCarga = rutaActual == AppRoutes.LOGIN || rutaActual == RUTA_CARGA

    // HU-04: al tocar la notificación se abre el detalle del silo afectado.
    LaunchedEffect(siloDesdeNotificacion) {
        if (siloDesdeNotificacion != null) {
            if (inicio == AppRoutes.HOME) navController.navigate(AppRoutes.detalle(siloDesdeNotificacion))
            onNotificacionAtendida()
        }
    }

    fun irA(ruta: String) {
        navController.navigate(ruta) {
            popUpTo(AppRoutes.HOME)
            launchSingleTop = true
        }
    }

    val abrirMenu: () -> Unit = { scope.launch { drawerState.open() } }
    val volver: () -> Unit = { navController.popBackStack() }

    val irACargaTransicion: () -> Unit = {
        navController.navigate(RUTA_CARGA) {
            popUpTo(AppRoutes.LOGIN) { inclusive = true }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = !enAutenticacionOCarga,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "Monitoreo de silos",
                    style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(start = 24.dp, top = 24.dp, end = 24.dp)
                )
                sesion?.let {
                    Text(
                        text = "${it.usuario} · ${it.rol.etiqueta}",
                        color = GrisTexto,
                        modifier = Modifier.padding(start = 24.dp, top = 4.dp, bottom = 16.dp)
                    )
                }
                NavigationDrawerItem(
                    label = { Text("Silos por granja") },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    selected = rutaActual == AppRoutes.HOME,
                    onClick = { scope.launch { drawerState.close() }; irA(AppRoutes.HOME) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Estado de silos") },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = null) },
                    selected = rutaActual == AppRoutes.ESTADO,
                    onClick = { scope.launch { drawerState.close() }; irA(AppRoutes.ESTADO) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                // NUEVA OPCIÓN: MI PERFIL
                NavigationDrawerItem(
                    label = { Text("Mi perfil") },
                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = null) },
                    selected = rutaActual == RUTA_PERFIL,
                    onClick = { scope.launch { drawerState.close() }; irA(RUTA_PERFIL) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Cerrar sesión") },
                    icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        authViewModel.cerrarSesion()
                        navController.navigate(AppRoutes.LOGIN) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
            Box(Modifier.systemBarsPadding().imePadding()) {
                NavHost(navController = navController, startDestination = inicio) {

                    // 1. PANTALLA DE LOGIN
                    composable(AppRoutes.LOGIN) {
                        LoginScreen(
                            onLoginExitoso = irACargaTransicion,
                        )
                    }

                    // 2. PANTALLA DE CARGA (TRANSICIÓN DE 3 SEGUNDOS)
                    composable(RUTA_CARGA) {
                        PantallaCargaTransicion(
                            onCargaCompletada = {
                                navController.navigate(AppRoutes.HOME) {
                                    popUpTo(RUTA_CARGA) { inclusive = true }
                                }
                            }
                        )
                    }

                    // 3. PANTALLA PRINCIPAL
                    composable(AppRoutes.HOME) {
                        SilosPorGranjaScreen(
                            onMenu = abrirMenu,
                            onSiloClick = { navController.navigate(AppRoutes.detalle(it)) }
                        )
                    }

                    composable(AppRoutes.ESTADO) {
                        EstadoSilosScreen(
                            onMenu = abrirMenu,
                            onSiloClick = { navController.navigate(AppRoutes.detalle(it)) },
                            onVolver = volver
                        )
                    }

                    composable(RUTA_PERFIL) {
                        PerfilUsuarioScreen(onVolver = volver)
                    }

                    composable(
                        route = AppRoutes.DETALLE,
                        arguments = listOf(navArgument("siloId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val siloId = backStackEntry.arguments?.getString("siloId").orEmpty()
                        DetalleSiloScreen(
                            puedeCoordinar = sesion?.rol.let { it == Rol.SUPERVISOR || it == Rol.JEFATURA },
                            onMenu = abrirMenu,
                            onRegistrarMovimiento = { navController.navigate(AppRoutes.movimiento(siloId)) },
                            onVolver = volver
                        )
                    }

                    composable(
                        route = AppRoutes.MOVIMIENTO,
                        arguments = listOf(navArgument("siloId") { type = NavType.StringType })
                    ) {
                        RegistrarMovimientoScreen(onTerminado = volver)
                    }
                }
            }
        }
    }
}