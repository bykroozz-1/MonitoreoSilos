package com.example.monitoreosilos.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.monitoreosilos.domain.model.Granja
import com.example.monitoreosilos.domain.model.enToneladas
import com.example.monitoreosilos.ui.components.BarraNivel
import com.example.monitoreosilos.ui.components.EncabezadoPantalla
import com.example.monitoreosilos.ui.components.EtiquetaEstado
import com.example.monitoreosilos.ui.components.FilaDatosSilo
import com.example.monitoreosilos.ui.components.InsigniaSolida
import com.example.monitoreosilos.ui.components.TarjetaBorde
import com.example.monitoreosilos.ui.theme.AmbarAdvertenciaFondo
import com.example.monitoreosilos.ui.theme.GrisBorde
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.theme.NaranjaMantenimiento
import com.example.monitoreosilos.ui.theme.VerdeActivo
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import com.example.monitoreosilos.ui.viewmodel.SilosViewModel

@Composable
fun SilosPorGranjaScreen(
    onMenu: () -> Unit,
    onSiloClick: (String) -> Unit,
    viewModel: SilosViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val granjas by viewModel.granjas.collectAsStateWithLifecycle()
    val pendientes by viewModel.pendientes.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            EncabezadoPantalla(
                titulo = "Silos por granja",
                subtitulo = "Identificador, alimento, capacidad y disponibilidad en tiempo real.",
                onMenu = onMenu
            )
        }
        if (pendientes > 0) {
            item { AvisoPendientes(pendientes) }
        }
        items(granjas, key = { it.id }) { granja ->
            TarjetaGranja(granja, onSiloClick)
        }
    }
}

@Composable
private fun AvisoPendientes(cantidad: Int) {
    Surface(shape = RoundedCornerShape(12.dp), color = AmbarAdvertenciaFondo) {
        Text(
            text = if (cantidad == 1) "1 movimiento pendiente de sincronizar"
            else "$cantidad movimientos pendientes de sincronizar",
            fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
    }
}

@Composable
private fun TarjetaGranja(granja: Granja, onSiloClick: (String) -> Unit) {
    TarjetaBorde {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(granja.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${granja.silos.size} silos activos", fontSize = 12.sp, color = GrisTexto)
            }
            InsigniaSolida(
                texto = granja.estado,
                color = if (granja.estado == "Mantenimiento") NaranjaMantenimiento else VerdeActivo
            )
        }
        Spacer(Modifier.height(8.dp))
        granja.silos.forEachIndexed { indice, silo ->
            if (indice > 0) HorizontalDivider(color = GrisBorde)
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { onSiloClick(silo.id) }
                    .padding(vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(silo.id, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GrisTexto)
                    Spacer(Modifier.padding(horizontal = 4.dp))
                    EtiquetaEstado(silo.estado)
                    Spacer(Modifier.weight(1f))
                    Text("${silo.porcentaje}% disponible", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                FilaDatosSilo(silo.tipo, silo.capacidadT.enToneladas(), silo.nivelT.enToneladas())
                Spacer(Modifier.height(8.dp))
                BarraNivel(silo.progreso)
            }
        }
    }
}
