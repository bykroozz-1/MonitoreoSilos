package com.example.monitoreosilos.data.prefs

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.monitoreosilos.domain.model.Sesion
import com.example.monitoreosilos.domain.model.Usuario
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val Context.perfilDataStore by preferencesDataStore(name = "perfil")

/**
 * Datos editables del perfil (nombre, correo, RUT y foto) guardados en el dispositivo.
 * Se guardan por usuario; cerrar sesión NO los borra.
 */
class PerfilRepository(private val context: Context) {

    private fun clave(usuario: String, campo: String) = stringPreferencesKey("${usuario}_$campo")

    fun perfil(sesion: Sesion): Flow<Usuario> = context.perfilDataStore.data.map { p ->
        val u = sesion.usuario
        Usuario(
            id = u,
            nombre = p[clave(u, "nombre")] ?: u,
            email = p[clave(u, "email")] ?: "${u.lowercase()}@empresa.cl",
            rol = sesion.rol,
            granjaAsignada = "Granja 01 - Melipilla",
            rut = (p[clave(u, "rut")] ?: "18.765.432-7").takeIf { it.isNotBlank() },
            fotoPath = p[clave(u, "foto")]?.takeIf { File(it).exists() }
        )
    }

    suspend fun guardarDatos(usuario: String, nombre: String, email: String, rut: String) {
        context.perfilDataStore.edit {
            it[clave(usuario, "nombre")] = nombre
            it[clave(usuario, "email")] = email
            it[clave(usuario, "rut")] = rut
        }
    }

    /** Foto tomada con la cámara (TakePicturePreview entrega un Bitmap). */
    suspend fun guardarFotoCamara(usuario: String, bitmap: Bitmap) = withContext(Dispatchers.IO) {
        val destino = archivoNuevo(usuario)
        FileOutputStream(destino).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        registrarFoto(usuario, destino)
    }

    /**
     * Foto elegida desde la galería: se COPIA al almacenamiento de la app, porque el permiso
     * sobre el Uri que entrega el selector es temporal.
     */
    suspend fun guardarFotoGaleria(usuario: String, uri: Uri) = withContext(Dispatchers.IO) {
        val destino = archivoNuevo(usuario)
        val entrada = context.contentResolver.openInputStream(uri) ?: return@withContext
        entrada.use { input -> FileOutputStream(destino).use { input.copyTo(it) } }
        registrarFoto(usuario, destino)
    }

    suspend fun quitarFoto(usuario: String) = withContext(Dispatchers.IO) {
        val kFoto = clave(usuario, "foto")
        val anterior = context.perfilDataStore.data.map { it[kFoto] }.first()
        context.perfilDataStore.edit { it.remove(kFoto) }
        anterior?.let { File(it).delete() }
    }

    // Nombre distinto en cada foto: así Coil no muestra una imagen vieja guardada en caché.
    private fun archivoNuevo(usuario: String): File {
        val dir = File(context.filesDir, "perfil").apply { mkdirs() }
        return File(dir, "${usuario}_${System.currentTimeMillis()}.jpg")
    }

    private suspend fun registrarFoto(usuario: String, archivo: File) {
        val kFoto = clave(usuario, "foto")
        val anterior = context.perfilDataStore.data.map { it[kFoto] }.first()
        context.perfilDataStore.edit { it[kFoto] = archivo.absolutePath }
        anterior?.takeIf { it != archivo.absolutePath }?.let { File(it).delete() }
    }
}
