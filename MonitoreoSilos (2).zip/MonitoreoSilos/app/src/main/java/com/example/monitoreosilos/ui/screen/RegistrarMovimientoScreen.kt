package com.example.monitoreosilos.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.monitoreosilos.domain.model.TipoMovimiento
import com.example.monitoreosilos.domain.model.enToneladas
import com.example.monitoreosilos.ui.components.BotonPrimario
import com.example.monitoreosilos.ui.components.BotonSecundario
import com.example.monitoreosilos.ui.components.CampoPildora
import com.example.monitoreosilos.ui.components.EncabezadoPantalla
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.theme.RojoCritico
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import com.example.monitoreosilos.ui.viewmodel.RegistrarMovimientoViewModel
import com.example.monitoreosilos.ui.viewmodel.UnidadCantidad

@Composable
fun RegistrarMovimientoScreen(
    onTerminado: () -> Unit,
    viewModel: RegistrarMovimientoViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val silo by viewModel.silo.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        EncabezadoPantalla(
            titulo = "Registrar movimiento",
            subtitulo = silo?.let { "${it.nombre} · ${it.granjaNombre} · nivel ${it.nivelT.enToneladas()}" }
        )
        Spacer(Modifier.height(24.dp))

        Text("Tipo de movimiento", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(TipoMovimiento.CARGA, TipoMovimiento.DESCARGA, TipoMovimiento.CONSUMO).forEach { tipo ->
                FilterChip(
                    selected = ui.tipo == tipo,
                    onClick = { viewModel.cambiarTipo(tipo) },
                    label = { Text(tipo.etiqueta) }
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Cantidad", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        CampoPildora(
            valor = ui.cantidad,
            onCambio = viewModel::cambiarCantidad,
            placeholder = "Ej: 120",
            teclado = KeyboardType.Decimal,
            error = ui.error
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            UnidadCantidad.entries.forEach { unidad ->
                FilterChip(
                    selected = ui.unidad == unidad,
                    onClick = { viewModel.cambiarUnidad(unidad) },
                    label = { Text(if (unidad == UnidadCantidad.TONELADAS) "Toneladas (t)" else "Kilos (kg)") }
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "La fecha y hora se asignan automáticamente. Sin conexión, el registro queda guardado en el " +
                "dispositivo como pendiente de sincronización.",
            style = MaterialTheme.typography.bodySmall,
            color = GrisTexto
        )

        Spacer(Modifier.height(24.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            BotonPrimario(
                texto = "Guardar movimiento",
                onClick = { viewModel.guardar(onTerminado) },
                habilitado = !ui.guardando
            )
            BotonSecundario("Cancelar", onTerminado)
        }
    }
}
