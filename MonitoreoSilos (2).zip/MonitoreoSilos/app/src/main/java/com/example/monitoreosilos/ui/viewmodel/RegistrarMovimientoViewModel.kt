package com.example.monitoreosilos.ui.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.monitoreosilos.data.repository.SiloRepository
import com.example.monitoreosilos.domain.model.Silo
import com.example.monitoreosilos.domain.model.TipoMovimiento
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class UnidadCantidad(val etiqueta: String, val factorATon: Double) {
    TONELADAS("t", 1.0),
    KILOS("kg", 0.001)
}

data class MovimientoUiState(
    val tipo: TipoMovimiento = TipoMovimiento.CARGA,
    val cantidad: String = "",
    val unidad: UnidadCantidad = UnidadCantidad.TONELADAS,
    val error: String? = null,
    val guardando: Boolean = false
)

class RegistrarMovimientoViewModel(
    handle: SavedStateHandle,
    private val repo: SiloRepository
) : ViewModel() {

    private val siloId: String = checkNotNull(handle.get<String>("siloId"))

    val silo: StateFlow<Silo?> = repo.silo(siloId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _ui = MutableStateFlow(MovimientoUiState())
    val ui = _ui.asStateFlow()

    fun cambiarTipo(tipo: TipoMovimiento) = _ui.update { it.copy(tipo = tipo, error = null) }
    fun cambiarUnidad(unidad: UnidadCantidad) = _ui.update { it.copy(unidad = unidad, error = null) }

    fun cambiarCantidad(texto: String) {
        val valido = texto.all { it.isDigit() || it == '.' } && texto.count { it == '.' } <= 1
        if (valido) _ui.update { it.copy(cantidad = texto, error = null) }
    }

    fun guardar(onExito: () -> Unit) {
        val estado = _ui.value
        val numero = estado.cantidad.toDoubleOrNull()
        if (numero == null || numero <= 0.0) {
            _ui.update { it.copy(error = "Ingresa una cantidad mayor a 0") }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(guardando = true) }
            repo.registrarMovimiento(siloId, estado.tipo, numero * estado.unidad.factorATon)
                .onSuccess { onExito() }
                .onFailure { e -> _ui.update { it.copy(guardando = false, error = e.message) } }
        }
    }
}
