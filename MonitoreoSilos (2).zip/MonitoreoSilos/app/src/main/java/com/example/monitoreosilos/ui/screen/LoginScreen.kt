package com.example.monitoreosilos.ui.screen

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.monitoreosilos.ui.components.BotonSecundario
import com.example.monitoreosilos.ui.components.CampoPildora
import com.example.monitoreosilos.ui.theme.AzulPrimario
import com.example.monitoreosilos.ui.theme.RojoCritico
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import com.example.monitoreosilos.ui.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
    onLoginExitoso: () -> Unit,
    viewModel: AuthViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val estado by viewModel.login.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        Text(
            text = "Iniciar sesión",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(32.dp))
        CampoPildora(
            valor = estado.usuario,
            onCambio = viewModel::onUsuarioLogin,
            placeholder = "Nombre de usuario",
            error = estado.errorUsuario
        )
        Spacer(Modifier.height(16.dp))
        CampoPildora(
            valor = estado.clave,
            onCambio = viewModel::onClaveLogin,
            placeholder = "Contraseña",
            esClave = true,
            error = estado.errorClave
        )
        if (estado.errorGeneral != null) {
            Spacer(Modifier.height(12.dp))
            Text(estado.errorGeneral!!, color = RojoCritico, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(24.dp))
        BotonSecundario(
            texto = "Continuar",
            onClick = { viewModel.iniciarSesion(onLoginExitoso) },
            habilitado = !estado.cargando
        )
        Spacer(Modifier.weight(1.4f))
        Spacer(Modifier.height(16.dp))
    }
}
