package com.example.monitoreosilos.ui.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.monitoreosilos.data.repository.SiloRepository
import com.example.monitoreosilos.domain.model.Movimiento
import com.example.monitoreosilos.domain.model.Silo
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DetalleSiloViewModel(
    handle: SavedStateHandle,
    private val repo: SiloRepository
) : ViewModel() {

    private val siloId: String = checkNotNull(handle.get<String>("siloId"))

    val silo: StateFlow<Silo?> = repo.silo(siloId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val movimientos: StateFlow<List<Movimiento>> = repo.movimientos(siloId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** HU-03: marcar / desmarcar "En proceso de reposición". */
    fun alternarReposicion(actual: Boolean) {
        viewModelScope.launch { repo.marcarReposicion(siloId, !actual) }
    }
}
