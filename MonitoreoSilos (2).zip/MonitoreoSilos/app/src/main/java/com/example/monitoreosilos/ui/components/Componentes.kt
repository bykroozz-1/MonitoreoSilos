package com.example.monitoreosilos.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.monitoreosilos.domain.model.EstadoSilo
import com.example.monitoreosilos.ui.theme.AzulPrimario
import com.example.monitoreosilos.ui.theme.GrisBorde
import com.example.monitoreosilos.ui.theme.GrisPista
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.theme.RojoCritico
import com.example.monitoreosilos.ui.theme.RosaCampo
import com.example.monitoreosilos.ui.theme.color
import com.example.monitoreosilos.ui.theme.fondo

/** Título grande + subtítulo gris + botón de menú (≡) a la derecha, como en las capturas. */
@Composable
fun EncabezadoPantalla(
    titulo: String,
    modifier: Modifier = Modifier,
    subtitulo: String? = null,
    onMenu: (() -> Unit)? = null,
    acciones: @Composable (() -> Unit)? = null
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(
                text = titulo,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            if (subtitulo != null) {
                Text(subtitulo, style = MaterialTheme.typography.bodySmall, color = GrisTexto)
            }
        }
        acciones?.invoke()
        if (onMenu != null) {
            IconButton(onClick = onMenu) {
                Icon(Icons.Default.Menu, contentDescription = "Abrir menú")
            }
        }
    }
}

/** Tarjeta blanca con borde gris fino y esquinas redondeadas. */
@Composable
fun TarjetaBorde(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val forma = RoundedCornerShape(16.dp)
    val colores = CardDefaults.cardColors(containerColor = Color.White)
    val borde = BorderStroke(1.dp, GrisBorde)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = forma, colors = colores, border = borde) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(modifier = modifier.fillMaxWidth(), shape = forma, colors = colores, border = borde) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

/** Insignia sólida: "Activo" (verde), "Mantenimiento" (naranja). */
@Composable
fun InsigniaSolida(texto: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color) {
        Text(
            text = texto,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

/** Etiqueta tenue Normal / Advertencia / Crítico. */
@Composable
fun EtiquetaEstado(estado: EstadoSilo) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = estado.fondo(),
        border = BorderStroke(1.dp, estado.color().copy(alpha = 0.35f))
    ) {
        Text(
            text = estado.etiqueta,
            color = estado.color(),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)
        )
    }
}

/** Barra azul sobre pista gris. progreso entre 0f y 1f. */
@Composable
fun BarraNivel(progreso: Float, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(50))
            .background(GrisPista)
    ) {
        Box(
            Modifier
                .fillMaxWidth(progreso.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(AzulPrimario)
        )
    }
}

/** Fila "Tipo | Capacidad | Nivel actual". */
@Composable
fun FilaDatosSilo(tipo: String, capacidad: String, nivel: String) {
    Row(Modifier.fillMaxWidth()) {
        Dato("Tipo", tipo, Modifier.weight(1f))
        Dato("Capacidad", capacidad, Modifier.weight(1f))
        Dato("Nivel actual", nivel, Modifier.weight(1f))
    }
}

@Composable
private fun Dato(etiqueta: String, valor: String, modifier: Modifier) {
    Column(modifier) {
        Text(etiqueta, fontSize = 11.sp, color = GrisTexto)
        Text(valor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Botón con borde en forma de píldora ("Volver", "Continuar"). */
@Composable
fun BotonSecundario(texto: String, onClick: () -> Unit, modifier: Modifier = Modifier, habilitado: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        enabled = habilitado,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, Color(0xFF8A8A8F)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1C1B1F)),
        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp)
    ) { Text(texto) }
}

/** Botón azul relleno en forma de píldora. */
@Composable
fun BotonPrimario(texto: String, onClick: () -> Unit, modifier: Modifier = Modifier, habilitado: Boolean = true) {
    Button(
        onClick = onClick,
        modifier = modifier,
        enabled = habilitado,
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(containerColor = AzulPrimario),
        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp)
    ) { Text(texto) }
}

/** Campo en píldora con fondo rosado (pantallas de sesión). */
@Composable
fun CampoPildora(
    valor: String,
    onCambio: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    esClave: Boolean = false,
    teclado: KeyboardType = KeyboardType.Text,
    error: String? = null
) {
    Column(modifier.fillMaxWidth()) {
        TextField(
            value = valor,
            onValueChange = onCambio,
            placeholder = { Text(placeholder) },
            singleLine = true,
            isError = error != null,
            shape = RoundedCornerShape(50),
            visualTransformation = if (esClave) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (esClave) KeyboardType.Password else teclado),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = RosaCampo,
                unfocusedContainerColor = RosaCampo,
                errorContainerColor = RosaCampo,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                errorIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        if (error != null) {
            Text(
                text = error,
                color = RojoCritico,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 20.dp, top = 2.dp)
            )
        }
    }
}

@Composable
fun PuntoLeyenda(color: Color, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(texto, fontSize = 11.sp)
    }
}
