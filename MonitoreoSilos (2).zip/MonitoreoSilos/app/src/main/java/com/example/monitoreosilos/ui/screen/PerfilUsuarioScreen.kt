package com.example.monitoreosilos.ui.screen

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.monitoreosilos.ui.components.BotonPrimario
import com.example.monitoreosilos.ui.components.BotonSecundario
import com.example.monitoreosilos.ui.components.InsigniaSolida
import com.example.monitoreosilos.ui.components.TarjetaBorde
import com.example.monitoreosilos.ui.theme.AzulPrimario
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import com.example.monitoreosilos.ui.viewmodel.PerfilViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerfilUsuarioScreen(
    onVolver: () -> Unit,
    viewModel: PerfilViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val usuario by viewModel.usuario.collectAsStateWithLifecycle()
    val form by viewModel.form.collectAsStateWithLifecycle()
    var mostrarOpcionesFoto by remember { mutableStateOf(false) }

    // Guía 13: la cámara y la galería se abren con contratos del sistema (sin permisos extra).
    val camara = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) viewModel.fotoDesdeCamara(bitmap)
    }
    val galeria = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.fotoDesdeGaleria(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mi Perfil") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        val u = usuario
        if (u == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Avatar: al tocarlo pregunta si la foto viene de la galería o de la cámara
                Box(Modifier.size(96.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(AzulPrimario)
                            .clickable { mostrarOpcionesFoto = true },
                        contentAlignment = Alignment.Center
                    ) {
                        if (u.fotoPath != null) {
                            AsyncImage(
                                model = File(u.fotoPath),
                                contentDescription = "Foto de perfil",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Text(
                                text = u.nombre.take(2).uppercase(),
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Surface(
                        modifier = Modifier.align(Alignment.BottomEnd).size(30.dp),
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 3.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.CameraAlt,
                                contentDescription = "Cambiar foto",
                                tint = AzulPrimario,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text(u.nombre, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                InsigniaSolida(texto = u.rol.etiqueta, color = AzulPrimario)
                Spacer(Modifier.height(24.dp))

                if (form.editando) {
                    // ---- Formulario de edición ----
                    TarjetaBorde {
                        Text(
                            "Editar perfil",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        OutlinedTextField(
                            value = form.nombre,
                            onValueChange = viewModel::onNombre,
                            label = { Text("Nombre completo") },
                            singleLine = true,
                            isError = form.errorNombre != null,
                            supportingText = form.errorNombre?.let { { Text(it) } },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = form.email,
                            onValueChange = viewModel::onEmail,
                            label = { Text("Correo electrónico") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            isError = form.errorEmail != null,
                            supportingText = form.errorEmail?.let { { Text(it) } },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = form.rut,
                            onValueChange = viewModel::onRut,
                            label = { Text("RUT") },
                            singleLine = true,
                            isError = form.errorRut != null,
                            supportingText = form.errorRut?.let { { Text(it) } },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "El cargo y la granja asignada los define la administración.",
                            fontSize = 12.sp,
                            color = GrisTexto
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            BotonSecundario(
                                texto = "Cancelar",
                                onClick = viewModel::cancelarEdicion,
                                modifier = Modifier.weight(1f)
                            )
                            BotonPrimario(
                                texto = "Guardar",
                                onClick = viewModel::guardar,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    // ---- Información de la cuenta ----
                    TarjetaBorde {
                        Text(
                            "Información de la Cuenta",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        FilaDatoPerfil(Icons.Default.Person, "Nombre Completo", u.nombre)
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        u.rut?.let {
                            FilaDatoPerfil(Icons.Default.Badge, "RUT", it)
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        }
                        FilaDatoPerfil(Icons.Default.Email, "Correo Electrónico", u.email)
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        FilaDatoPerfil(Icons.Default.Work, "Cargo / Rol Asignado", u.rol.etiqueta)
                        u.granjaAsignada?.let {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))
                            FilaDatoPerfil(Icons.Default.LocationOn, "Granja Asignada", it)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    BotonPrimario(texto = "Editar perfil", onClick = viewModel::iniciarEdicion)
                    Spacer(Modifier.height(12.dp))
                    BotonSecundario(texto = "Volver", onClick = onVolver)
                }
            }
        }

        // Diálogo: ¿galería o cámara?
        if (mostrarOpcionesFoto) {
            val tieneFoto = usuario?.fotoPath != null
            AlertDialog(
                onDismissRequest = { mostrarOpcionesFoto = false },
                title = { Text("Foto de perfil") },
                text = {
                    Column {
                        OpcionFoto(Icons.Default.PhotoLibrary, "Elegir de la galería") {
                            mostrarOpcionesFoto = false
                            galeria.launch("image/*")
                        }
                        OpcionFoto(Icons.Default.PhotoCamera, "Tomar con la cámara") {
                            mostrarOpcionesFoto = false
                            camara.launch(null)
                        }
                        if (tieneFoto) {
                            OpcionFoto(Icons.Default.Delete, "Quitar foto") {
                                mostrarOpcionesFoto = false
                                viewModel.quitarFoto()
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { mostrarOpcionesFoto = false }) { Text("Cancelar") }
                }
            )
        }
    }
}

@Composable
private fun OpcionFoto(icono: ImageVector, texto: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(texto) },
        leadingContent = { Icon(icono, contentDescription = null, tint = AzulPrimario) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun FilaDatoPerfil(icono: ImageVector, etiqueta: String, valor: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(icono, contentDescription = null, tint = AzulPrimario, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(etiqueta, fontSize = 11.sp, color = GrisTexto)
            Text(valor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}
