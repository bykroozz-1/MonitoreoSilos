package com.example.monitoreosilos

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.monitoreosilos.ui.navigation.AppNavigation
import com.example.monitoreosilos.ui.theme.MonitoreoSilosTheme

class MainActivity : ComponentActivity() {

    private var siloDesdeNotificacion by mutableStateOf<String?>(null)

    private val pedirPermisoNotificaciones =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Tema claro fijo (como en el diseño): íconos oscuros en las barras del sistema.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        siloDesdeNotificacion = intent?.getStringExtra(EXTRA_SILO_ID)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pedirPermisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            MonitoreoSilosTheme {
                AppNavigation(
                    siloDesdeNotificacion = siloDesdeNotificacion,
                    onNotificacionAtendida = { siloDesdeNotificacion = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        siloDesdeNotificacion = intent.getStringExtra(EXTRA_SILO_ID)
    }

    companion object {
        const val EXTRA_SILO_ID = "silo_id"
    }
}
