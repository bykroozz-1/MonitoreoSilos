package com.example.monitoreosilos.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

private const val SELECT_SILO_GRANJA = """
    SELECT s.id AS id, s.granjaId AS granjaId, g.nombre AS granjaNombre, s.tipo AS tipo,
           s.capacidadT AS capacidadT, s.nivelT AS nivelT, s.enReposicion AS enReposicion
    FROM silos s JOIN granjas g ON g.id = s.granjaId
"""

@Dao
interface SiloDao {
    @Transaction
    @Query("SELECT * FROM granjas ORDER BY id")
    fun granjasConSilos(): Flow<List<GranjaConSilos>>

    @Query("$SELECT_SILO_GRANJA ORDER BY s.id")
    fun silosConGranja(): Flow<List<SiloConGranjaRow>>

    @Query("$SELECT_SILO_GRANJA ORDER BY s.id")
    suspend fun silosConGranjaUnaVez(): List<SiloConGranjaRow>

    @Query("$SELECT_SILO_GRANJA WHERE s.id = :id")
    fun siloConGranja(id: String): Flow<SiloConGranjaRow?>

    @Query("SELECT * FROM silos WHERE id = :id")
    suspend fun obtener(id: String): SiloEntity?

    @Query("SELECT COUNT(*) FROM silos")
    suspend fun contarSilos(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarGranjas(granjas: List<GranjaEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarSilos(silos: List<SiloEntity>)

    @Query("UPDATE silos SET nivelT = :nivel WHERE id = :id")
    suspend fun actualizarNivel(id: String, nivel: Double)

    @Query("UPDATE silos SET enReposicion = :valor WHERE id = :id")
    suspend fun marcarReposicion(id: String, valor: Boolean)
}

@Dao
interface MovimientoDao {
    @Query("SELECT * FROM movimientos WHERE siloId = :siloId ORDER BY fechaHora DESC")
    fun porSilo(siloId: String): Flow<List<MovimientoEntity>>

    @Insert
    suspend fun insertar(movimiento: MovimientoEntity): Long

    @Query("SELECT COUNT(*) FROM movimientos WHERE pendienteSync = 1")
    fun contarPendientes(): Flow<Int>

    @Query("SELECT * FROM movimientos WHERE pendienteSync = 1")
    suspend fun pendientes(): List<MovimientoEntity>

    @Query("UPDATE movimientos SET pendienteSync = 0 WHERE id IN (:ids)")
    suspend fun marcarSincronizados(ids: List<Long>)
}

@Dao
interface UsuarioDao {
    @Query("SELECT * FROM usuarios WHERE usuario = :usuario LIMIT 1")
    suspend fun buscar(usuario: String): UsuarioEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertar(usuario: UsuarioEntity): Long
}
