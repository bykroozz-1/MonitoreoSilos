package com.example.monitoreosilos

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.monitoreosilos.data.AppContainer
import com.example.monitoreosilos.worker.AlertaSilosWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class SilosApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        crearCanalAlertas()
        programarAlertas()
        CoroutineScope(Dispatchers.IO).launch { container.sembrarDatosIniciales() }
    }

    private fun crearCanalAlertas() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CANAL_ALERTAS,
                "Alertas de silos",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Avisos cuando un silo alcanza nivel crítico (<15%)" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
        }
    }

    /** HU-04 / RF-06: revisión periódica en segundo plano (mínimo permitido: 15 min). */
    private fun programarAlertas() {
        val trabajo = PeriodicWorkRequestBuilder<AlertaSilosWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "alerta_silos",
            ExistingPeriodicWorkPolicy.KEEP,
            trabajo
        )
    }

    companion object {
        const val CANAL_ALERTAS = "alertas_silos"
    }
}
