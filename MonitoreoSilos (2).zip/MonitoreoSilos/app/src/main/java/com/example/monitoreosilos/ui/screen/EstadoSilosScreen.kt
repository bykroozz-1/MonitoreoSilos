package com.example.monitoreosilos.ui.screen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.monitoreosilos.domain.model.EstadoSilo
import com.example.monitoreosilos.domain.model.Silo
import com.example.monitoreosilos.ui.components.BotonSecundario
import com.example.monitoreosilos.ui.components.EncabezadoPantalla
import com.example.monitoreosilos.ui.components.EtiquetaEstado
import com.example.monitoreosilos.ui.components.PuntoLeyenda
import com.example.monitoreosilos.ui.theme.GrisBorde
import com.example.monitoreosilos.ui.theme.GrisChip
import com.example.monitoreosilos.ui.theme.GrisTexto
import com.example.monitoreosilos.ui.theme.color
import com.example.monitoreosilos.ui.theme.fondo
import com.example.monitoreosilos.ui.viewmodel.AppViewModelProvider
import com.example.monitoreosilos.ui.viewmodel.SilosViewModel
import androidx.compose.foundation.clickable

@Composable
fun EstadoSilosScreen(
    onMenu: () -> Unit,
    onSiloClick: (String) -> Unit,
    onVolver: () -> Unit,
    viewModel: SilosViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val silos by viewModel.silos.collectAsStateWithLifecycle()
    val criticoPrimero by viewModel.criticoPrimero.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        EncabezadoPantalla(
            titulo = "Selección silo y estado",
            subtitulo = "Todas las granjas • ${silos.size} silos",
            onMenu = onMenu,
            acciones = {
                Surface(shape = RoundedCornerShape(8.dp), color = GrisChip) {
                    Text(
                        "HOY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        )
        Spacer(Modifier.height(12.dp))

        // Leyenda del semáforo
        Surface(shape = RoundedCornerShape(12.dp), color = GrisChip, modifier = Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                EstadoSilo.entries.forEach { PuntoLeyenda(it.color(), it.etiqueta) }
            }
        }
        Spacer(Modifier.height(8.dp))
        FilterChip(
            selected = criticoPrimero,
            onClick = viewModel::alternarCriticoPrimero,
            label = { Text("Crítico primero") }
        )
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(silos, key = { it.id }) { silo -> FilaSilo(silo, onSiloClick) }
        }

        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            BotonSecundario("Volver", onVolver)
        }
    }
}

@Composable
private fun FilaSilo(silo: Silo, onClick: (String) -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = androidx.compose.ui.graphics.Color.White,
        border = BorderStroke(1.dp, GrisBorde),
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onClick(silo.id) }
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(silo.estado.fondo()),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Inventory2, contentDescription = null, tint = silo.estado.color(), modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.padding(horizontal = 6.dp))
            Column(Modifier.weight(1f)) {
                Text(silo.nombre, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text(silo.granjaNombre, fontSize = 11.sp, color = GrisTexto)
            }
            Column(horizontalAlignment = Alignment.End) {
                EtiquetaEstado(silo.estado)
                Spacer(Modifier.height(2.dp))
                Text("${silo.porcentaje}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = silo.estado.color())
            }
        }
    }
}
